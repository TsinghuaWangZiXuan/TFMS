
var actions = [
  {
    "element_id": "wx_navigator66f8813b", 
    "data": {
      "args": {
        "url": "../page1/page1", 
        "a_ids": [], 
        "e_ids": [], 
        "open_type": "navigate", 
        "st": 1
      }, 
      "type": 0, 
      "exec": 5
    }, 
    "id": "M_66a4299eb6dc2a01", 
    "isNew": true
  }
];

var animations = [];

var timelines = [
  {
    "data": {
      "type": 0, 
      "t": {
        "rv": 0, 
        "rp": 0, 
        "wa": 0, 
        "de": 0, 
        "st": 1, 
        "du": 1, 
        "es": 0
      }, 
      "d": {}
    }, 
    "element_id": "body_35903286ca376725", 
    "iType": 0, 
    "id": "M_d12aaa5c9cb3ec5d", 
    "animations": [
      "ani_73f7d41cb7680a6a", 
      "ani_1791701171b46b14"
    ]
  }
];

getApp().coolsite360.DATA[__wxRoute] = {
   animations:animations,
   actions:actions,
   timelines:timelines
};

